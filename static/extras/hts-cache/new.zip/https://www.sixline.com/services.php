
<!DOCTYPE html>
<html lang="en">
<HEAD>
<TITLE>Thailand nationwide lottery .</TITLE>
  	<meta charset="utf-8">
  	<meta http-equiv="X-UA-Compatible" content="IE=edge">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<META content="The Thailand nationwide lottery and results check."  name="description">
	<META content="thai,Thailand,Thai,lotto,Lottery,lottery,tip,tips " name="keywords">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<style>
body {
background: #8E0000;
color: #ffffff;
font-family: 'Open Sans', sans-serif;
margin: 0;
font-size: 18px; line-height: 1.4;padding: 1em;}
p {margin: 0 0 1.4em;}
@media all and (min-width: 800px) {
  .container {
  }
  .columns  {
        height:50vh;
  column-count: 2;        
  column-gap: 2em;
  }
}
@media (max-width: 576px) {
    html { font-size: 0.7rem; }
    th { font-size:0.9rem; }
     td { font-size: 0.9rem; }
}
@media (min-width: 768px) {
    html { font-size: 0.8rem; }
    th { font-size:1rem; }
     td { font-size: 1rem; }

}
@media (min-width: 992px) {
    html { font-size: 0.8rem; }
    th { font-size: 1rem; }
}
@media (min-width: 1200px) {
    html { font-size: 0.8rem; }
    th { font-size: 1rem; }
}
A:link {
	COLOR: orange; TEXT-DECORATION: none
}
A:visited {
	COLOR: orange; TEXT-DECORATION: none
}
A:hover {
	COLOR: red; TEXT-DECORATION:none
}


h1   {
color:  silver;
font-size: 200%;
font-weight: 500;
text-align: center;
padding-top: 3%

}
h2   {
color:  silver;
font-size: 150%;
font-weight: 400;
text-align: center;
padding-top: 2%

}
h3  {
color:  silver;
font-size: 100%;
font-weight: 300;
text-align: justify;
padding-top: 1%

}
p {
font-family: 'Open Sans', sans-serif;
color: #F5F5F5;
font-size: 160%;
line-height: 150%;
padding: 5%;
text-indent: 2%;
text-align: justify;
}
hr   {color: green;}
img {
	max-width: 100%;
	height: auto;
	margin-top: 5px;
  display: block;
  margin: 0 auto;


}
#rcorners1 {
    border-radius: 25px;
    background: #73AD21;
    padding: 20px; 
    width: 300px;
    height: 100px;    
}

#rcorners2 {
    border-radius: 25px;
    border: 2px solid #73AD21;
    padding: 20px; 
    width: 300px;
    height: 150px;    
}
#rcorners_menu {
    border-radius: 10px;
    border: 20px solid green;
    padding: 10px; 
    width: 280px;
    height: 80px;   
     background: green; 
}

#rcorners3 {
    border-radius: 25px;
    background: url(paper.gif);
    background-position: left top;
    background-repeat: repeat;
    padding: 20px; 
    width: 200px;
    height: 150px;    
}


.nav ul li a{
    color:red !important;
   font-family: 'Open Sans', sans-serif !important;
  font-size: 1.5em ;
  padding: 1px 1px 1px ;
}


 #main
{
    margin: 42px auto;
    position:relative;
    background:rgba(16,16,17,0.70);
    width:90%;
    box-shadow: 3px 3px 2.5px #888888;
    border-radius:5px;
}   

h1 {
    text-align: center;
    color: #fff;
    font-size: 2em;
}

.red {
    color: red;
}

.map
{
    display:inline;
    margin: 0 5px 0;
    border-radius:5px;
    border-style:solid;
    border-width:2px;
    border-color:#fff;
}

.address {
    display:inline;
    vertical-align: top;
}
a.button3{
display:inline-block;
padding:0.3em 1.2em;
margin:0 0.3em 0.3em 0;
border-radius:2em;
box-sizing: border-box;
text-decoration:none;
font-family:'Roboto',sans-serif;
font-weight:300;
color:#FFFFFF;
background-color:#4eb5f1;
text-align:center;
transition: all 0.2s;
}
a.button3:hover{
background-color:#4095c6;
}
@media all and (max-width:30em){
a.button3{
display:block;
margin:0.2em auto;
}
}
/* Style the header */
.header {
  padding: 10px 16px;
 /* background: #555;*/
  color: #f1f1f1;
  z-index:1;
}

/* Page content */
.content {
  padding: 16px;
}

/* The sticky class is added to the header with JS when it reaches its scroll position */
.sticky {
  position: fixed;
  top: 0;
  width: 95%
}

/* Add some top padding to the page content to prevent sudden quick movement (as the header gets a new position at the top of the page (position:fixed and top:0) */
.sticky + .content {
  padding-top: 102px;
}

.navbar-inverse {
    background-color:#8E0000;
}
.circular--landscape {
  display: inline-block;
  position: relative;
  width: 60px;
  height:50px;
  overflow: hidden;
  border-radius: 50%;
}

.circular--landscape img {
  width: auto;
  height: 100%;
  margin-left: -20x;
 margin-right: -20x;
}
#footer{
     background-color: #33383c;
     padding:30px 0px;
}	       

.logo{
    color:#FFF;
    font-weight:700;
    font-size:30px;
}

.address span , .menu span{
   color: #FFF; 
   font-weight: bold; 
   border-bottom: 1px solid #c7c7c7; 
   padding:10px 0px;
   display: block;
   text-transform: uppercase;
   font-size: 16px;
   letter-spacing: 3px;
}
 
.address li a , .menu li a{
    color:#FFF;
    letter-spacing: 3px;
    text-decoration:none;
    font-size:14px;
}

.address li, .menu li{
    margin:20px 0px;
    list-style: none;
}

.address li a:hover , .menu li a:hover{
    color: #da3e44;
    -webkit-transition: all 1s ease-in-out;
    -moz-transition: all 1s ease-in-out;
    -o-transition: all 1s ease-in-out;
    transition: all 1s ease-in-out;
}

.address .fa{
    color: #da3e44;
    margin-right: 10px;
    font-size:18px;
}

 a, a:hover {
	text-decoration: none;
}

.socialbtns, .socialbtns ul, .socialbtns li {
	margin: 0;
	padding: 5px;
}

.socialbtns li {
    list-style: none outside none;
    display: inline-block;
}

.socialbtns .fa {
    color: #FFF;
	background-color: #000;
	width: 40px;
    height: 28px;
    padding-top: 12px;
	border-radius: 20px;
	-moz-border-radius: 20px;
	-webkit-border-radius: 20px;
	-o-border-radius: 20px;
  transition: all ease 0.3s;
    -moz-transition: all ease 0.3s;
    -webkit-transition: all ease 0.3s;
    -o-transition: all ease 0.3s;
  	transform: rotate(-360deg);
	-moz-transform: rotate(-360deg);
	-webkit-transform: rotate(-360deg);
	-o-transform: rotate(-360deg);
}

.socialbtns .fa:hover {
	transition: all ease 0.3s;
    -moz-transition: all ease 0.3s;
    -webkit-transition: all ease 0.3s;
    -o-transition: all ease 0.3s;
	transform: rotate(360deg);
	-moz-transform: rotate(360deg);
	-webkit-transform: rotate(360deg);
	-o-transform: rotate(360deg);
}
</style>
  </head>
  <body>
 <div class="header" id="myHeader">
      <div class="navbar navbar-fixed-top">
        <div class="navbar-inner">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
  <a class="navbar-brand" href="https://www.sixline.com/index.php" id="logo">
<div class="circular--landscape">
    <img alt="avatar" class="profile-pic" src="../image/logo.png" alt="">
</div>
</a>    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="https://www.sixline.com/index.php">Home</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Lottery tips  <span class="caret"></span></a>
          <ul class="dropdown-menu">
	<li><a href="https://www.sixline.com/general">VIP.free tips</a></li>
            <li><a href="https://www.sixline.com/preview_tip.php">VIP.tip Preview</a></li>
            <li><a href="https://www.sixline.com/graph_tip.php">Statistic</a></li>
          </ul>
        </li>
        <li><a href="https://www.sixline.com/vip_payment.php">Payment</a></li>
        <li><a href="https://www.sixline.com/services.php">Services</a></li>
               <li><a href="https://www.sixline.com/contact_me.php">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="https://www.sixline.com/sign_up.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
        <li><a href="https://www.sixline.com/login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav>
  </div>
  </div>	
  </div>
<div class="container-fluid">
<div class="row">

  <div class="col-sm-9" style="background-color:#8E0000;">
 
  <div class="row">
    <center><p>
     All our lottery tips are collected from statistics and lottery resources in Thailand.
          <br>
To boost your odds of winning numbers, SignUp & make payment to be VIP. membership. 
</p>
<hr>
<h1> VIP. MEMBERSHIP SERVICE FEE</h1>
<br>
 <br>
<center>

<!--Currency Converter widget by FreeCurrencyRates.com -->

<div id='gcw_mainFaCJO3Fj8' class='gcw_mainFaCJO3Fj8'></div>
<a id='gcw_siteFaCJO3Fj8' href='https://freecurrencyrates.com/en/'>FreeCurrencyRates.com</a>
<script>function reloadFaCJO3Fj8(){ var sc = document.getElementById('scFaCJO3Fj8');if (sc) sc.parentNode.removeChild(sc);sc = document.createElement('script');sc.type = 'text/javascript';sc.charset = 'UTF-8';sc.async = true;sc.id='scFaCJO3Fj8';sc.src = 'https://freecurrencyrates.com/en/widget-horizontal?iso=THB-BTC-ETH-XUM&df=2&p=FaCJO3Fj8&v=i&source=fcr&width=220&width_title=110&firstrowvalue=1&thm=A6C9E2,FCFDFD,4297D7,5C9CCC,FFFFFF,C5DBEC,FCFDFD,2E6E9E,000000&title=Currency%20Converter&tzo=-420';var div = document.getElementById('gcw_mainFaCJO3Fj8');div.parentNode.insertBefore(sc, div);} reloadFaCJO3Fj8(); </script>
<!-- put custom styles here: .gcw_mainFaCJO3Fj8{}, .gcw_headerFaCJO3Fj8{}, .gcw_ratesFaCJO3Fj8{}, .gcw_sourceFaCJO3Fj8{} -->
<!--End of Currency Converter widget by FreeCurrencyRates.com -->
<br>
<table border='1' width='80%' align='center' bgcolor='silver'>
<tr>
<td align='center'><b>Service fee</b></td>
<td align='center'><b>ThaiBaht</b></td>
</tr>
<tr>
<td align='center'>1 month</td>
<td align='center'>500</td>
</tr>
<tr>
<td align='center'>2 months</td>
<td align='center'>950</td>
</tr>
<tr>
<td align='center'>4 months</td>
<td align='center'>1800</td>
</tr>
<tr>
<td align='center'>6 months</td>
<td align='center'>2500</td>
</tr>
<tr>
<td align='center'>12 months</td>
<td align='center'>4500</td>
</tr>
</table></center>
<a href="https://www.sixline.com/vip_payment.php" class="button3">PAYMENT CONFIRMED</a>
<h3 class=\"text-center\"><b>Payment via</b></h3>
<center>
<a href='https://www.sixline.com/m/deposit_member_btc.php'><img src='https://www.phuketnight.net/image/btc_acc.png' class='map' width='220'></a>
<a href='https://www.sixline.com/m/deposit_member_eth.php'><img src='https://www.phuketnight.net/image/eth_acc.jpg' class='map' width='220'></a>
<hr>
<h3 class=\"text-center\">Direct to our Bank account </h3>
<img src='/image/world_money.png' class='map'>
</center>



   <br>
      <h2>Services detail & Disclaimer</h2>
<table width='80%'class="table .table">
<tr>
              <td align="right" valign='top' width="10">&#160;</td>
              <td width="564" align="left"><li>You can easy payment our service fee from worldwide via <b>Internet Banking</b> or <b> Crypto Wallets</b>.
</td>
            </tr>
   <tr>
              <td align="right" valign='top' width="10">&#160;</td>
              <td width="564" align="left"><li> The service fee have been charged for maintenance the system space and resources.
</td>
            </tr>
   <tr>
            <td align="right" valign='top' width="10">&#160;</td>
              <td width="564" align="left"><li>All Tips which our collected are all about Thailand lottery forecast . It just a forecast can be right or wrong.
</td>
            </tr>
              <tr>
            <td align="right" valign='top' width="10">&#160;</td>
              <td width="564" align="left">
<li> We can not say that you will win when you buy our service, but we only do the best that we can do.
</td>
            </tr>
            <tr>
              <td align="right" valign='top' width="10">&#160;</td>
              <td width="564" align="left"><li>We sell the service to you if you need to buy it and can not refund.
</td>
            </tr>
            <tr>
            <td align="right" valign='top' width="10">&#160;</td>
              <td width="564" align="left"><li>All our Tips are collected from Magazines about Thailand lottery forecast.</td>
            </tr>
            <tr>
             <td align="right" valign='top' width="10">&#160;</td>
              <td width="564" align="left"><li>All our Tips just a forecast. It can be wrong.</td>
            </tr>
  <tr>
              <td align="right" valign='top' width="10">&#160;</td>
              <td width="564" align="left"><li>Our the best collect Tips will be updated around  1 - 5 day before the draw or every 15 & 31 or 30 of the month.</td>
            </tr>
  <tr>
              <td align="right" valign='top' width="10">&#160;</td>
              <td width="564" align="left"><li>You should Sign Up to be our Membership. Then we will guide you how to log-in and payment via informations by email.</td>
            </tr>
<tr>
  <td align="right" valign='top' width="10">&#160;</td>
              <td width="564" align="left"><li>After 1st. register, You will get PASSWORD for Log-In on your E-mail and you will have procedure and details to be our membership step by step via responding E-mail.</td>
            </tr>
<tr>
  <td align="right" valign='top' width="10">&#160;</td>
              <td width="564" align="left"><li>Feel free to contact Sixline's staff by E-mail address: <a href="/cdn-cgi/l/email-protection#b1c2c5d0d7d7f1c2d8c9ddd8dfd49fd2dedc"><span class="__cf_email__" data-cfemail="2b585f4a4d4d6b5842534742454e05484446">[email&#160;protected]</span></a> 24 Hrs.<br></td>
            </tr>
          </table> 

          </center>
     </div>
     </div>
     </div>
      </div>
<hr>
              
<footer>
 <div class="container">
   <div class="row">
   
            <div class="col-md-4 col-sm-6 col-xs-12">
              <span class="logo"><div>
  <a href="https://www.phuketnight.net"><img style="background-color: snow" src="https://www.phuketnight.net/image/logo1.png" border="0" width="364" class="img-rounded" align="middle"></a></div></span>
            </div>
            
            <div class="col-md-4 col-sm-6 col-xs-12">
                <ul class="menu">
                     <span>Menu</span> 
     <li>
                        <a href="https://www.sixline.com/login.php">Login</a>
                      </li>
 <li>
                       <a href="https://www.sixline.com/sign_up.php">Sign Up</a>
                      </li>  
                     <li>
                        <a href="https://www.sixline.com/services.php">VIP.Lottery Tips</a>
                      </li>   
                      <li>
                        <a href="https://www.phuketnight.net">Play Lottery</a>
                      </li>
					   
                 </ul>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
		 <ul class="menu">
                    <span>INFO</span>   
               <li>
                        <a href="https://www.sixline.com/vip_payment.php">Renew</a>
                      </li>
                      <li>
                       <a href="https://www.sixline.com/pw_reset.php">Reset password</a>
                      </li>   
               </ul>
              <ul class="menu">
                    <span>Contact</span>   
                    <li>
                       <i class="fa fa-envelope" aria-hidden="true"></i><a href="/cdn-cgi/l/email-protection#0e7d7a6f68684e7d67766267606b206d6163"> <span class="__cf_email__" data-cfemail="17646376717157647e6f7b7e79723974787a">[email&#160;protected]</span></a>
                    </li> 
               </ul>
           </div>
       
       
       </div> 
    </div>
</footer>
  <div align="center" class="socialbtns">
<ul> 
<li><a href="https://www.facebook.com/ISasima1234" class="fa fa-lg fa-facebook"></a></li>
<li><a href="https://www.youtube.com/channel/UCr2jVjs1Ukj07rXqyl8QvGQ" class="fa fa-lg fa-youtube"></a></li>
<li><a href="https://www.instagram.com/naayyungaesngkracchaang/" class="fa fa-lg fa-instagram"></a></li>
<li><a href="/cdn-cgi/l/email-protection#4a393e2b2c2c0a3923322623242f64292527" class="fa fa-lg fa-envelope"></a></li>

  </ul>
</div>

			
		

    
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>

  </body>
</html>

