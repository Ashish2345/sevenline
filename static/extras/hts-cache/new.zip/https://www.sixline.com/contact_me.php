
<!DOCTYPE html>
<html lang="en">
<HEAD>
<TITLE>Thailand nationwide lottery .</TITLE>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">  
  	<META content="The Thailand nationwide lottery and results check."  name="description">
	<META content="thai,Thailand,Thai,lotto,Lottery,lottery play,tip,tips,lottery bet " name="keywords">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />

</head>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-3815731600051787",
    enable_page_level_ads: true
  });
</script>

<style>
body {
background: #8E0000;
color: #ffffff;
font-family: 'Open Sans', sans-serif;
margin: 0;
font-size: 18px; line-height: 1.4;padding:0px;}
p {margin: 0 0 1.4em;}


* {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column {
  float: left;
  width: 50%;
  padding: 10px;
  //height: 400px; 
/* Should be removed. Only for demonstration */
height: auto; 
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
  }
}
A:link {
	COLOR: orange; TEXT-DECORATION: none
}
A:visited {
	COLOR: orange; TEXT-DECORATION: none
}
A:hover {
	COLOR: red; TEXT-DECORATION:none
}


h1   {
color:  silver;
font-size: 250%;
font-weight: 700;
text-align: center;
padding-top: 2%

}
h2   {
color:  silver;
font-size: 250%;
font-weight: 700;
text-align: center;
padding-top: 2%

}
h3  {
color:  silver;
font-size: 150%;
font-weight: 300;
text-align: justify;
padding-top: 1%

}
p {
font-family: 'Open Sans', sans-serif;
color: #F5F5F5;
font-size: 150%;
line-height: 150%;
padding: 5%;
text-indent: 2%;
text-align: justify;
}
h4 {
font-family: 'Open Sans', sans-serif;
color: #F5F500;
font-size: 160%;
line-height: 150%;
padding: 5%;
text-indent: 3%;
text-align: justify;
}
hr   {color: green;}
img {
	max-width: 100%;
	height: auto;
	margin-top: 5px;
  display: block;
  margin: 0 auto;


}
#rcorners1 {
    border-radius: 25px;
    background: #73AD21;
    padding: 20px; 
    width: 300px;
    height: 100px;    
}

#rcorners2 {
    border-radius: 25px;
    border: 2px solid #73AD21;
    padding: 20px; 
    width: 300px;
    height: 250px;    
}
#rcorners_menu {
    border-radius: 10px;
    border: 20px solid green;
    padding: 10px; 
    width: 280px;
    height: 80px;   
     background: green; 
}

#rcorners3 {
    border-radius: 25px;
    background: url(paper.gif);
    background-position: left top;
    background-repeat: repeat;
    padding: 20px; 
    width: 200px;
    height: 150px;    
}


.nav ul li a{
    color: red !important;
   font-family: 'Open Sans', sans-serif !important;
  font-size: 1.5em ;
  padding: 1px 1px 1px ;
}

td {
    background-color: #CDD7FB;
    color: black;
    font-size:13px;
}

th {
    background-color: #4CAF50;
    color: white;
    font-size:13px;
 }
 #main
{
    margin: 42px auto;
    position:relative;
    background:rgba(16,16,17,0.70);
    max-width: 95%;
    box-shadow: 3px 3px 2.5px #888888;
    border-radius:5px;
}   

h1 {
    text-align: center;
    color: #fff;
    font-size: 2em;
}

.red {
    color: red;
}

.map
{
    display:inline;
    margin: 5px 5px 5px;
    border-radius:5px;
    border-style:solid;
    border-width:2px;
    border-color:#fff;
}

.address {
    display:inline;
    vertical-align: top;
}
/* Style the header */
.header {
  padding: 10px 10px;
 /* background: #555;*/
  color: #f1f1f1;
  z-index:1;
}

/* Page content */
.content {
  padding: 16px;
}

/* The sticky class is added to the header with JS when it reaches its scroll position */
.sticky {
  position: fixed;
  top: 100;
  width: 100%
}

/* Add some top padding to the page content to prevent sudden quick movement (as the header gets a new position at the top of the page (position:fixed and top:0) */
.sticky + .content {
  padding-top: 100px;
}
.navbar-inverse {
    background-color:#8E0000;
}

.circular--landscape {
  display: inline-block;
  position: relative;
  width: 60px;
  height:50px;
  overflow: hidden;
  border-radius: 50%;
}

.circular--landscape img {
  width: auto;
  height: 100%;
  margin-left: -20x;
 margin-right: -20x;
}
#content-desktop {display: block;}
#content-mobile {display: none;}

@media screen and (max-width: 768px) {
#content-desktop {display: none;}
#content-mobile {display: block;}
}
footer{
     background-color: #350B0C;
     padding:30px 0px;
}	       

.logo{
    color:#FFF;
    font-weight:700;
    font-size:30px;
}

.address span , .menu span{
   color: #FFF; 
   font-weight: bold; 
   border-bottom: 1px solid #c7c7c7; 
   padding:10px 0px;
   display: block;
   text-transform: uppercase;
   font-size: 16px;
   letter-spacing: 3px;
}
 
.address li a , .menu li a{
    color:#FFF;
    letter-spacing: 3px;
    text-decoration:none;
    font-size:14px;
}

.address li, .menu li{
    margin:20px 0px;
    list-style: none;
}

.address li a:hover , .menu li a:hover{
    color: #da3e44;
    -webkit-transition: all 1s ease-in-out;
    -moz-transition: all 1s ease-in-out;
    -o-transition: all 1s ease-in-out;
    transition: all 1s ease-in-out;
}

.address .fa{
    color: #da3e44;
    margin-right: 10px;
    font-size:18px;
}

 a, a:hover {
	text-decoration: none;
}

.socialbtns, .socialbtns ul, .socialbtns li {
	margin: 0;
	padding: 5px;
}

.socialbtns li {
    list-style: none outside none;
    display: inline-block;
}

.socialbtns .fa {
    color: #FFF;
	background-color: #000;
	width: 40px;
    height: 28px;
    padding-top: 12px;
	border-radius: 20px;
	-moz-border-radius: 20px;
	-webkit-border-radius: 20px;
	-o-border-radius: 20px;
  transition: all ease 0.3s;
    -moz-transition: all ease 0.3s;
    -webkit-transition: all ease 0.3s;
    -o-transition: all ease 0.3s;
  	transform: rotate(-360deg);
	-moz-transform: rotate(-360deg);
	-webkit-transform: rotate(-360deg);
	-o-transform: rotate(-360deg);
}

.socialbtns .fa:hover {
	transition: all ease 0.3s;
    -moz-transition: all ease 0.3s;
    -webkit-transition: all ease 0.3s;
    -o-transition: all ease 0.3s;
	transform: rotate(360deg);
	-moz-transform: rotate(360deg);
	-webkit-transform: rotate(360deg);
	-o-transform: rotate(360deg);
}

</style>
  </head>
  <body>
 
 <div class="header" id="myHeader">
      <div class="navbar navbar-fixed-top">
        <div class="navbar-inner">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
  <a class="navbar-brand" href="https://www.sixline.com/index.php" id="logo">
<div class="circular--landscape">
    <img alt="avatar" class="profile-pic" src="../image/logo.png" alt="">
</div>
</a>    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="https://www.sixline.com/index.php">Home</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Lottery tips  <span class="caret"></span></a>
          <ul class="dropdown-menu">
	<li><a href="https://www.sixline.com/general">VIP.free tips</a></li>
            <li><a href="https://www.sixline.com/preview_tip.php">VIP.tip Preview</a></li>
            <li><a href="https://www.sixline.com/graph_tip.php">Statistic</a></li>
          </ul>
        </li>
        <li><a href="https://www.sixline.com/vip_payment.php">Payment</a></li>
        <li><a href="https://www.sixline.com/services.php">Services</a></li>
               <li><a href="https://www.sixline.com/contact_me.php">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="https://www.sixline.com/sign_up.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
        <li><a href="https://www.sixline.com/login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav>
  </div>
  </div>	
  </div>
<div class="container-fluid">
<div class="row">
  <div class="col-sm-3">
  <div id="content-desktop">
   <div>
<br><br>
   <img src="https://www.sixline.com/image/qr_sixline.png" class="img-rounded" align="middle" alt="www.sixline.com" width="304" height="236"> 
  </div>
   </div>
   </div>
  <div class="col-sm-9" style="background-color:#010410;">
<br><br>
 <p>
To boost your odds of winning numbers, SignUp & make payment to be VIP. membership. 
</p>
<hr>
  <h2>Contact </h2>
  <h3>
email:<a href="/cdn-cgi/l/email-protection#b8cbccd9dedef8cbd1c0d4d1d6dd96dbd7d5"><span class="__cf_email__" data-cfemail="deadaabfb8b89eadb7a6b2b7b0bbf0bdb1b3">[email&#160;protected]</span></a>
<br>For common questions or to reach our Support team.<br><br> 
  </h3>
      </div>
      </div>
  <hr>
               
<footer>
 <div class="container">
   <div class="row">
   
            <div class="col-md-4 col-sm-6 col-xs-12">
              <span class="logo"><div>
  <a href="https://www.phuketnight.net"><img style="background-color: snow" src="https://www.phuketnight.net/image/logo1.png" border="0" width="364" class="img-rounded" align="middle"></a></div></span>
            </div>
            
            <div class="col-md-4 col-sm-6 col-xs-12">
                <ul class="menu">
                     <span>Menu</span> 
     <li>
                        <a href="https://www.sixline.com/login.php">Login</a>
                      </li>
 <li>
                       <a href="https://www.sixline.com/sign_up.php">Sign Up</a>
                      </li>  
                     <li>
                        <a href="https://www.sixline.com/services.php">VIP.Lottery Tips</a>
                      </li>   
                      <li>
                        <a href="https://www.phuketnight.net">Play Lottery</a>
                      </li>
					   
                 </ul>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
		 <ul class="menu">
                    <span>INFO</span>   
               <li>
                        <a href="https://www.sixline.com/vip_payment.php">Renew</a>
                      </li>
                      <li>
                       <a href="https://www.sixline.com/pw_reset.php">Reset password</a>
                      </li>   
               </ul>
              <ul class="menu">
                    <span>Contact</span>   
                    <li>
                       <i class="fa fa-envelope" aria-hidden="true"></i><a href="/cdn-cgi/l/email-protection#9deee9fcfbfbddeef4e5f1f4f3f8b3fef2f0"> <span class="__cf_email__" data-cfemail="45363124232305362c3d292c2b206b262a28">[email&#160;protected]</span></a>
                    </li> 
               </ul>
           </div>
       
       
       </div> 
    </div>
</footer>
  <div align="center" class="socialbtns">
<ul> 
<li><a href="https://www.facebook.com/ISasima1234" class="fa fa-lg fa-facebook"></a></li>
<li><a href="https://www.youtube.com/channel/UCr2jVjs1Ukj07rXqyl8QvGQ" class="fa fa-lg fa-youtube"></a></li>
<li><a href="https://www.instagram.com/naayyungaesngkracchaang/" class="fa fa-lg fa-instagram"></a></li>
<li><a href="/cdn-cgi/l/email-protection#74070015121234071d0c181d1a115a171b19" class="fa fa-lg fa-envelope"></a></li>

  </ul>
</div>

			
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>
  </body>
</html>

